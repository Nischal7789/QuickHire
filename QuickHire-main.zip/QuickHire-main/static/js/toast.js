(function () {
    window.toast = function (msg, type) {
        type = type || 'success';
        let el = document.getElementById('__toast');
        if (!el) {
            el = document.createElement('div');
            el.id = '__toast';
            el.className = 'toast';
            el.innerHTML = `<span class="toast-icon"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></span><span class="toast-msg"></span>`;
            document.body.appendChild(el);
        }
        el.className = 'toast ' + type;
        el.querySelector('.toast-msg').textContent = msg;
        el.classList.add('show');
        setTimeout(() => el.classList.remove('show'), 2800);
    };
})();
